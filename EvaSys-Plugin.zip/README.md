EvasysPlugin
============

Plugin for Stud.IP to manage and provide evaluations with EvaSys by Electric Paper
