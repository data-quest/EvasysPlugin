<?php

class ExpireScheme extends Migration
{
    function up()
    {
        //SimpleORMap::expireTableScheme();
    }
}