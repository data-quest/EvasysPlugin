<table class="default" id="evasys_logs">
    <caption>
        <?= dgettext("evasys", "SOAP-Logeinträge") ?>
    </caption>
    <thead>
        <tr>
            <th width="16"></th>
            <th><?= dgettext("evasys", "SOAP-Methode") ?></th>
            <th><?= dgettext('evasys', 'Benutzer') ?></th>
            <th><?= dgettext("evasys", "Dauer (ms)") ?></th>
            <th><?= dgettext("evasys", "Zeitpunkt") ?></th>
            <th class="actions"><?= dgettext("evasys", "Aktion") ?></th>
        </tr>
    </thead>
    <tbody>
        <? foreach ($logs as $log) : ?>
            <?= $this->render_partial("logs/_row", ['log' => $log, 'plugin' => $plugin]) ?>
        <? endforeach ?>
    </tbody>
    <tfoot>
    <? if ($more) : ?>
        <tr class="more">
            <td colspan="5" style="text-align: center">
                <?= Assets::img("ajax-indicator-black.svg") ?>
            </td>
        </tr>
    <? endif ?>
    </tfoot>
</table>

<input type="hidden" id="function" value="<?= htmlReady(Request::get('function')) ?>">
<input type="hidden" id="search" value="<?= htmlReady(Request::get('search')) ?>">

<script>
    //Infinity-scroll:
    jQuery(window.document).bind('scroll', _.throttle(function (event) {
        if ((jQuery(window).scrollTop() + jQuery(window).height() > jQuery(window.document).height() - 1200)
            && (jQuery("#evasys_logs .more").length > 0)) {
            //nachladen
            jQuery("#evasys_logs .more").removeClass("more").addClass("loading");
            let earliest = null;
            jQuery("#evasys_logs tbody > tr").each(function () {
                if (earliest === null || earliest > jQuery(this).data("id")) {
                    earliest = jQuery(this).data("id");
                }
            });
            jQuery.ajax({
                url: STUDIP.ABSOLUTE_URI_STUDIP + "plugins.php/evasysplugin/logs/more",
                data: {
                    'earliest': earliest,
                    'function': $('#function').val(),
                    'search': $('#search').val()
                },
                dataType: "json",
                success: function (response) {
                    for (let i in response.rows) {
                        jQuery("#evasys_logs tbody").append(response.rows[i]);
                    }
                    if (response.more) {
                        jQuery("#evasys_logs .loading").removeClass("loading").addClass("more");
                    } else {
                        jQuery("#evasys_logs .loading").remove();
                    }
                }
            });
        }
    }, 30));
</script>

<?
$search = new SearchWidget(PluginEngine::getURL($plugin, ['function' => Request::get('function')], 'logs/index'));
$search->addNeedle(
    _('Suche'),
    'search',
    '',
    null,
    null,
    Request::get('search')
);
Sidebar::Get()->addWidget($search);
