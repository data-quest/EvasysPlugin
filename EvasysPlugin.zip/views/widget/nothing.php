<div style="padding: 10px;">
    <?= MessageBox::info(dgettext("evasys", "Dieses Widget ist nur sinnvoll, wenn die EvaSys-Kursprofile aktiviert sind, was in diesem Stud.IP nicht der Fall ist.")) ?>
</div>